package it.andrianid.ptfanalyzer.service.service;

import java.util.List;
import it.andrianid.ptfanalyzer.service.dto.PtfStatisticheDto;
import it.andrianid.ptfanalyzer.service.dto.RendimentiDto;
import it.andrianid.ptfanalyzer.service.dto.StatisticheDto;
import it.andrianid.ptfanalyzer.service.model.Posizione;

public interface StockServiceInterface {

	List<RendimentiDto> extractRendimento(String codTitolo);

	List<StatisticheDto> extractStat(String codTitolo);

	List<PtfStatisticheDto> extractStatPtf(List<Posizione> titoliAzionari);

	double calcolaRendimentoMedioPesato(List<Posizione> titoliAzionari);

}
