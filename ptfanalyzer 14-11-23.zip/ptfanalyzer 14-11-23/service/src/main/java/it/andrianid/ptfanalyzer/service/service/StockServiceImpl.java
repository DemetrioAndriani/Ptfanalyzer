package it.andrianid.ptfanalyzer.service.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.andrianid.ptfanalyzer.service.dao.StockDao;
import it.andrianid.ptfanalyzer.service.dto.PtfStatisticheDto;
import it.andrianid.ptfanalyzer.service.dto.RendimentiDto;
import it.andrianid.ptfanalyzer.service.dto.StatisticheDto;
import it.andrianid.ptfanalyzer.service.model.Posizione;
import it.andrianid.ptfanalyzer.service.model.Titolo;

public class StockServiceImpl implements StockServiceInterface {

	private Logger logger = LoggerFactory.getLogger(StockDao.class);

	public StockServiceImpl() {
		logger.debug("costruttore " + this.getClass().getName());
	}

	

	public List<RendimentiDto> extractRendimento(String codTitolo) {
		StockDao stockDao = new StockDao();
		List<Titolo> rendimento = stockDao.extractAllData(codTitolo);

		List<RendimentiDto> stockDtoRendimento = new ArrayList<>();

		for (Titolo stock : rendimento) {
			RendimentiDto stockDtoR = new RendimentiDto(null, 0, 0, 0);
			stockDtoR.setDate(stock.getDate());
			stockDtoR.setClose(stock.getClose());
			stockDtoR.setRend(stock.getRend());
			stockDtoR.setRendPerc(stock.getRendPerc());

			stockDtoRendimento.add(stockDtoR);
			logger.info("Rendimenti estratti: " + stockDtoR.toString());
		}

		return stockDtoRendimento;

	}

	public List<StatisticheDto> extractStat(String codTitolo) {
		StockDao stockDao = new StockDao();
		List<Titolo> rend = stockDao.extractAllData(codTitolo);

		List<Double> rendimenti = new ArrayList<>();
		for (Titolo stock : rend) {
			rendimenti.add(stock.getRend());
		}

		StatisticheDto statistics = new StatisticheDto(rendimenti);

		List<StatisticheDto> stockDtoStatistics = new ArrayList<>();
		stockDtoStatistics.add(statistics);

		return stockDtoStatistics;
	}



	public Map<String, Double> extractPesiDaControvalori(List<Posizione> titoliAzionari) {
	    if (titoliAzionari == null || titoliAzionari.isEmpty()) {
	        throw new IllegalArgumentException("Errore: titoliAzionari assenti o vuoti");
	    }

	    Map<String, Double> pesiTitoli = new HashMap<>();
	    double sum = 0.0;

	    // Calcolo della somma totale dei controvalori
	    for (Posizione posizione : titoliAzionari) {
	        sum += posizione.getControvalore();
	    }

	    // Calcolo dei pesi in base ai controvalori
	    for (Posizione posizione : titoliAzionari) {
	        String titolo = posizione.getCodTitolo();
	        double controvalore = posizione.getControvalore();

	        double peso = controvalore / sum;
	        if (peso > 1.0 || peso <= 0.0) {
	            throw new IllegalArgumentException(
	                    "Errore: La somma dei pesi deve essere compresa tra 0 e 1");
	        }
	        pesiTitoli.put(titolo, peso);
	    }

	    return pesiTitoli;
	}


	@Override
	public double calcolaRendimentoMedioPesato(List<Posizione> titoliAzionari) {
	    if (titoliAzionari == null || titoliAzionari.isEmpty()) {
	        throw new IllegalArgumentException("Errore: titoliAzionari assenti o vuoti");
	    }

	    Map<String, Double> pesiTitoli = extractPesiDaControvalori(titoliAzionari);

	    double weightedReturnSum = 0.0;
	    double weightSum = 0.0;

	    // Itera attraverso le posizioni anziché la mappa
	    for (Posizione posizione : titoliAzionari) {
	        String titolo = posizione.getCodTitolo();
	        double controvalore = posizione.getControvalore();

	        if (pesiTitoli.containsKey(titolo)) {
	            double pesoTitolo = pesiTitoli.get(titolo);
	            List<RendimentiDto> rendimentiTitolo = extractRendimento(titolo);

	            if (rendimentiTitolo != null && !rendimentiTitolo.isEmpty()) {
	                double sum = 0.0;

	                // Calcola la somma dei rendimenti
	                for (RendimentiDto rendimento : rendimentiTitolo) {
	                    sum += rendimento.getRend();
	                }

	                // Calcola la media dei rendimenti per il titolo
	                double mediaRendimentoTitolo = sum / rendimentiTitolo.size();

	                weightedReturnSum += mediaRendimentoTitolo * (pesoTitolo * controvalore);
	                weightSum += pesoTitolo * controvalore;
	            }
	        }
	    }

	    if (weightSum == 0.0) {
	        return 0; // Evita la divisione per zero
	    }

	    return weightedReturnSum / weightSum;
	}


	@Override
	public List<PtfStatisticheDto> extractStatPtf(List<Posizione> titoliAzionari) {
	    if (titoliAzionari == null || titoliAzionari.isEmpty()) {
	        return new ArrayList<>(); 
	    }

	    List<PtfStatisticheDto> statisticsList = new ArrayList<>();

	    for (Posizione posizione : titoliAzionari) {
	        String titolo = posizione.getCodTitolo();  
	        //Double controvalore = posizione.getControvalore();  

	        StockDao stockDao = new StockDao();
	        List<Titolo> rendimenti = stockDao.extractAllData(titolo);

	        if (!rendimenti.isEmpty()) {
	            List<Double> rendimentiSingoloTitolo = new ArrayList<>();
	            for (Titolo stock : rendimenti) {
	                rendimentiSingoloTitolo.add(stock.getRend());
	            }

	            StatisticheDto statisticheTitolo = new StatisticheDto(rendimentiSingoloTitolo);

	            PtfStatisticheDto portfolioStat = new PtfStatisticheDto(rendimentiSingoloTitolo,
	                    Collections.singletonList(titolo));
	            portfolioStat.setMediaRendimenti(statisticheTitolo.getMediaRendimenti());
	            portfolioStat.setDeviazioneStandard(statisticheTitolo.getDeviazioneStandard());
	            portfolioStat.setMassimoDrawdown(statisticheTitolo.getMassimoDrawdown());
	            portfolioStat.setMassimoRendimento(statisticheTitolo.getMassimoRendimento());
	            portfolioStat.setMinimoRendimento(statisticheTitolo.getMinimoRendimento());
	            portfolioStat.setValorePercentile99(statisticheTitolo.getValorePercentile99());

	            statisticsList.add(portfolioStat);
	        }
	    }

	    return statisticsList;
	}
}
