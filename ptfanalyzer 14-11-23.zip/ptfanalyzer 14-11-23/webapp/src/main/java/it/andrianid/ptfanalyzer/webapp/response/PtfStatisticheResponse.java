package it.andrianid.ptfanalyzer.webapp.response;

import java.util.List;

import it.andrianid.ptfanalyzer.service.dto.PtfStatisticheDto;


public class PtfStatisticheResponse extends ResponseStandard{
	private String rendimentoMedioPesato;
	private List<PtfStatisticheDto> statPtfData;

	public List<PtfStatisticheDto> getStatistichePtf() {
		return statPtfData;
	}

	public void setStatistichePtf(List<PtfStatisticheDto> statistics) {
		this.statPtfData = statistics;
	}
	
	public String getRendimentoMedioPesato() {
		return rendimentoMedioPesato;
	}

	public void setRendimentoMedioPesato(String rendimentoMedioPesato) {
		this.rendimentoMedioPesato = rendimentoMedioPesato;
	}

	
}
