package it.andrianid.ptfanalyzer.webapp.response;

import java.util.List;

import it.andrianid.ptfanalyzer.service.dto.StatisticheDto;


public class StatisticheResponse extends ResponseStandard{
	private List<StatisticheDto> statistiche;

	public List<StatisticheDto> getStatistiche() {
		return statistiche;
	}

	public void setStatistiche(List<StatisticheDto> res) {
		this.statistiche = res;
	}
}
