package it.andrianid.ptfanalyzer.service.model;

import java.util.List;

public class Titolo {
	private String codTitolo;
	private String OsservazioniStoriche;
	private List<String>  ScenariFuturi;
	
	public String getCodTitolo() {
		return codTitolo;
	}
	public void setCodTitolo(String codTitolo) {
		this.codTitolo = codTitolo;
	}
	public String getOsservazioniStoriche() {
		return OsservazioniStoriche;
	}
	public void setOsservazioniStoriche(String osservazioniStoriche) {
		OsservazioniStoriche = osservazioniStoriche;
	}
	public List<String>  getScenariFuturi() {
		return ScenariFuturi;
	}
	public void setScenariFuturi(List<String> scenariFuturi) {
		ScenariFuturi = scenariFuturi;
	}
	
	@Override
	public String toString() {
		return "Titolo [codTitolo=" + codTitolo + ", OsservazioniStoriche=" + OsservazioniStoriche + ", ScenariFuturi="
				+ ScenariFuturi + "]";
	}
	

	
}
