package it.andrianid.ptfanalyzer.service.model;

import java.util.Arrays;

public class ScenariFuturi {// giorni(5 piloni)
    private double[] statisticaAllaData;

    public ScenariFuturi() {
        this.statisticaAllaData = new double[5];
    }

    public ScenariFuturi(double[] statisticaAllaData) {
        // Assicurati che l'array sia di dimensione 5
        if (statisticaAllaData.length != 5) {
            throw new IllegalArgumentException("L'array dei rendimenti deve essere di dimensione 5");
        }
        this.statisticaAllaData = statisticaAllaData;
    }

    public double[] getRendimenti() {
        return statisticaAllaData;
    }

    public void setRendimenti(double[] statisticaAllaData) {
        // Assicurati che l'array sia di dimensione 5
        if (statisticaAllaData.length != 5) {
            throw new IllegalArgumentException("L'array dei rendimenti deve essere di dimensione 5");
        }
        this.statisticaAllaData = statisticaAllaData;
    }

	@Override
	public String toString() {
		return "Scenario [rendimenti=" + Arrays.toString(statisticaAllaData) + "]";
	}
    
}