package it.andrianid.ptfanalyzer.service.dto;

import java.util.Arrays;
import java.util.Date;
import java.text.SimpleDateFormat;

public class RendimentoConoDto {
	private Date date;
	private double percentile5;
	private double percentile50;
	private double percentile95;
	
	public String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(date);
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	public double getPercentile5() {
		return percentile5;
	}
	public void setPercentile5(double percentile5) {
		this.percentile5 = percentile5;
	}
	public double getPercentile50() {
		return percentile50;
	}
	public void setPercentile50(double percentile50) {
		this.percentile50 = percentile50;
	}
	public double getPercentile95() {
		return percentile95;
	}
	public void setPercentile95(double percentile95) {
		this.percentile95 = percentile95;
	}
	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate = sdf.format(date);

		return "RendimentiConoDto [date=" + formattedDate + ", percentile5=" + percentile5 + ", percentile50=" + percentile50
				+ ", percentile95=" + percentile95 + "]";
	}
	
	public double calcolaPercentile(double[] rendimentiCumulati, int percentuale) {
	    if (rendimentiCumulati == null || rendimentiCumulati.length == 0) {
	        throw new IllegalArgumentException("L'array dei rendimenti cumulati è vuoto o nullo.");
	    }

	    // Ordina l'array dei rendimenti cumulati
	    double[] sortedArray = Arrays.copyOf(rendimentiCumulati, rendimentiCumulati.length);
	    Arrays.sort(sortedArray);

	    // Calcola l'indice del percentile
	    int index = (int) Math.ceil((percentuale / 100.0) * sortedArray.length) - 1;

	    // Restituisci il valore corrispondente all'indice calcolato
	    return sortedArray[index];
	}

	// Metodo per calcolare il percentile al 5%
	public double calcolaPercentile5(double[] rendimentiCumulati) {
	    return calcolaPercentile(rendimentiCumulati, 5);
	}

	// Metodo per calcolare il percentile al 50%
	public double calcolaPercentile50(double[] rendimentiCumulati) {
	    return calcolaPercentile(rendimentiCumulati, 50);
	}

	// Metodo per calcolare il percentile al 95%
	public double calcolaPercentile95(double[] rendimentiCumulati) {
	    return calcolaPercentile(rendimentiCumulati, 95);
	}


}
