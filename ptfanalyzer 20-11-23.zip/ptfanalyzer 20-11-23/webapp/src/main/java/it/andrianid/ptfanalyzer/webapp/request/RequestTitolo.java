package it.andrianid.ptfanalyzer.webapp.request;

public class RequestTitolo extends RequestStandard{

	private String codTitolo;

	public String getCodTitolo() {
        return codTitolo;
    }

    public void setCodTitolo(String codTitolo) {
        this.codTitolo = codTitolo;
    }
}
