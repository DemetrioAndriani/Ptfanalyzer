package it.andrianid.ptfanalyzer.webapp.request;


public class RequestStandard {
    private String uniqueId; 
	private Long generatedAt; //forma aaaammddhhmmss (20231113103924)
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public Long getGeneratedAt() {
		return generatedAt;
	}
	public void setGeneratedAt(Long generatedAt) {
		this.generatedAt = generatedAt;
	}
	
	
}
