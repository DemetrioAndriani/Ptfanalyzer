package it.andrianid.ptfanalyzer.webapp.request;

import java.util.List;

import it.andrianid.ptfanalyzer.service.model.Posizione;


public class RequestPtf extends RequestStandard {
    private Portfolio portfolio;

    public Portfolio getPortfolio() {
        return portfolio;
    }

    public void setPortfolio(Portfolio portfolio) {
        this.portfolio = portfolio;
    }

    public class Portfolio {
        private List<Posizione> posizioni;

        public List<Posizione> getPosizioni() {
            return posizioni;
        }

        public void setPosizioni(List<Posizione> posizioni) {
            this.posizioni = posizioni;
        }
    }
}
