package it.andrianid.ptfanalyzer.webapp;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponses;
import it.andrianid.ptfanalyzer.service.dto.PtfStatisticheDto;
import it.andrianid.ptfanalyzer.service.dto.RendimentoConoDto;
import it.andrianid.ptfanalyzer.service.dto.RendimentiDto;
import it.andrianid.ptfanalyzer.service.dto.StatisticheDto;
import it.andrianid.ptfanalyzer.service.model.Posizione;
import it.andrianid.ptfanalyzer.service.model.StatisticaAllaData;
import it.andrianid.ptfanalyzer.service.service.StockServiceImpl;
import it.andrianid.ptfanalyzer.service.service.StockServiceInterface;
import it.andrianid.ptfanalyzer.webapp.request.RequestPtf;
import it.andrianid.ptfanalyzer.webapp.request.RequestTitolo;
import it.andrianid.ptfanalyzer.webapp.response.PtfStatisticheResponse;
import it.andrianid.ptfanalyzer.webapp.response.RendimentoConoResponse;
import it.andrianid.ptfanalyzer.webapp.response.RendimentoResponse;
import it.andrianid.ptfanalyzer.webapp.response.StatisticheResponse;

@Path("/ptfanalyzer")
@Api(value = "Ptfanalyzer")
public class PtfanalyzerService {

	@POST //endpoint 1
	@Path("/serieStoricaTitolo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "returns historical data for a single instrument")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Historical data for the instrument is available.", response = RendimentoResponse.class ),
			@ApiResponse(code = 404, message = "Historical data not available for the requested instrument") })
	@ApiParam(name = "request", value = "mandatory fields: codTitolo")
	public RendimentoResponse getDatiStoriciTitolo(RequestTitolo request) {
		long startTime = System.currentTimeMillis();

		String uniqueId = request.getUniqueId();

		String codTitolo = request.getCodTitolo();
		StockServiceInterface service = new StockServiceImpl();
		List<RendimentiDto> res = service.extractRendimento(codTitolo);

		RendimentoResponse response = new RendimentoResponse();

		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String formattedDate = dateFormat.format(currentDate);

		if (res != null && !res.isEmpty()) {
			response.setStatus(200);
			response.setMessage("I dati storici del titolo sono disponibili.");
			response.setRendimentoData(res);
			response.setGeneratedAt(formattedDate);
			response.setUniqueId(uniqueId);
			long endTime = System.currentTimeMillis();
			long duration = endTime - startTime;
			response.setElaborationInMilliSec(duration);

		} else {
			response.setStatus(404);
			response.setMessage("Dati storici non disponibili per il titolo richiesto.");
		}

		return response;
	}

	@POST // endpoint 2 
	@Path("/statTitolo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "returns statistics of a single instrument")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "statistics for the instrument is available.", response = StatisticheResponse.class ),
			@ApiResponse(code = 404, message = "statistics not available for the requested instrument") })
	@ApiParam(name = "request", value = "mandatory fields: codTitolo")
	public StatisticheResponse getStatTitolo(RequestTitolo request) {
		long startTime = System.currentTimeMillis();

		String uniqueId = request.getUniqueId();

		String codTitolo = request.getCodTitolo();
		StockServiceInterface service = new StockServiceImpl();
		List<StatisticheDto> res = service.extractStat(codTitolo);

		StatisticheResponse response = new StatisticheResponse();

		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String formattedDate = dateFormat.format(currentDate);

		if (res != null && !res.isEmpty()) {
			response.setStatus(200);
			response.setMessage("Le Statistiche titolo sono disponibili.");
			response.setStatistiche(res);
			response.setGeneratedAt(formattedDate);
			response.setUniqueId(uniqueId);
			long endTime = System.currentTimeMillis();
			long duration = endTime - startTime;
			response.setElaborationInMilliSec(duration);

		} else {
			response.setStatus(404);
			response.setMessage("Statistiche non disponibili");
		}

		return response;
	}




	@POST // endpoint 3
	@Path("/portfolioRendimentoMedioPesato")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "returns statistics of a single portfolio")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "statistics for the portfolio is available.", response = PtfStatisticheResponse.class ),
			@ApiResponse(code = 404, message = "statistics not available for the requested portfolio") })
	@ApiParam(name = "request", value = "mandatory fields: portfolio")
	public PtfStatisticheResponse getStatistichePortfolio(RequestPtf requestPtf) {
		long startTime = System.currentTimeMillis();

		String uniqueId = requestPtf.getUniqueId();
	    RequestPtf.Portfolio portfolio = requestPtf.getPortfolio();

	    if (portfolio != null) {
	        List<Posizione> titoliAzionari = portfolio.getPosizioni();
	        StockServiceInterface service = new StockServiceImpl();
	        List<PtfStatisticheDto> statistics = service.extractStatPtf(titoliAzionari);

	        PtfStatisticheResponse response = new PtfStatisticheResponse();

		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String formattedDate = dateFormat.format(currentDate);
		
		try {
			
			double rendimentoMedioPesato = service.calcolaRendimentoMedioPesato(titoliAzionari);
			
			DecimalFormat decimalFormat = new DecimalFormat("#.#########"); 
		    String rendimentoMedioPesatoFormatted = decimalFormat.format(rendimentoMedioPesato);

		    
			response.setStatus(200);
			response.setMessage("Le statistiche del portafoglio sono disponibili.");
			response.setStatistichePtf(statistics);
			response.setRendimentoMedioPesato(rendimentoMedioPesatoFormatted);
			response.setGeneratedAt(formattedDate);
			response.setUniqueId(uniqueId);
			
			long endTime = System.currentTimeMillis();
			long duration = endTime - startTime;
			response.setElaborationInMilliSec(duration);
			
			return response;
			
		} catch (IllegalArgumentException e) {
			PtfStatisticheResponse errorResponse = new PtfStatisticheResponse();
			errorResponse.setStatus(400);
			errorResponse.setMessage("Errore nel calcolo del rendimento medio pesato: " + e.getMessage());

			return errorResponse;
		}
	    } else {
			PtfStatisticheResponse errorResponse = new PtfStatisticheResponse();
			errorResponse.setStatus(400);
			errorResponse.setMessage("Errore nel calcolo del rendimento medio pesato: ");

			return errorResponse;
		}
	}
	
	
	
	@POST // endpoint4
	@Path("/elaborazioneCono")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Calcola le statistiche future per un portafoglio")
	@ApiResponses(value = {
	        @ApiResponse(code = 200, message = "Statistiche future calcolate con successo", response = RendimentoConoResponse.class),
	        @ApiResponse(code = 400, message = "Richiesta non valida"),
	        @ApiResponse(code = 404, message = "Dati storici non disponibili per uno o più titoli del portafoglio") })
	public RendimentoConoResponse elaborazioneCono(RequestPtf requestPtf) {
	    long startTime = System.currentTimeMillis();

	    String uniqueId = requestPtf.getUniqueId();
	    RequestPtf.Portfolio portfolio = requestPtf.getPortfolio();

	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	    if (portfolio != null) {
	        List<Posizione> titoliAzionari = portfolio.getPosizioni();
	        StockServiceInterface service = new StockServiceImpl();
	        List<RendimentoConoDto> risultati = new ArrayList<>();

	        Calendar calendar = Calendar.getInstance();

	        for (int i = 0; i < 5; i++) {
	            // Incrementa la data di 1 giorno alla volta
	            calendar.add(Calendar.DAY_OF_MONTH, 1);

	            Date currentDate = calendar.getTime();
	            String formattedDate = dateFormat.format(currentDate);

	            for (Posizione posizione : titoliAzionari) {
	                String codTitolo = posizione.getCodTitolo();
	                List<StatisticaAllaData> stockDtoStatistiche = service.bootstrap(codTitolo);
	                double[] rendimentiCumulati = service.calcolaRendimentiCumulati(stockDtoStatistiche);

	                RendimentoConoDto risultato = new RendimentoConoDto();
	                risultato.setDate(currentDate);
	                risultato.setPercentile5(service.calcolaPercentile(rendimentiCumulati, 5));
	                risultato.setPercentile50(service.calcolaPercentile(rendimentiCumulati, 50));
	                risultato.setPercentile95(service.calcolaPercentile(rendimentiCumulati, 95));

	                risultati.add(risultato);
	            }
	        }

	        long endTime = System.currentTimeMillis();
	        long duration = endTime - startTime;

	        RendimentoConoResponse response = new RendimentoConoResponse();
	        response.setStatus(200);
	        response.setMessage("Statistiche future calcolate con successo.");
	        response.setRendimentoCono(risultati);
	        response.setGeneratedAt(dateFormat.format(Calendar.getInstance().getTime())); // Data corrente
	        response.setUniqueId(uniqueId);
	        response.setElaborationInMilliSec(duration);

	        return response;

	    } else {
	        RendimentoConoResponse errorResponse = new RendimentoConoResponse();
	        errorResponse.setStatus(400);
	        errorResponse.setMessage("Errore: richiesta non valida.");

	        return errorResponse;
	    }
	}


}