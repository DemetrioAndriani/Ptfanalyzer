package it.andrianid.ptfanalyzer.service.model;

import java.util.List;

public class Portfolio {
    
	private List<String> titoliAzionari;
    private List<Double> pesiTitoli;
    
	public List<String> getTitoliAzionari() {
		return titoliAzionari;
	}
	
	public void setTitoliAzionari(List<String> titoliAzionari) {
		this.titoliAzionari = titoliAzionari;
	}
	
	public List<Double> getPesiTitoli() {
		return pesiTitoli;
	}
	
	public void setPesiTitoli(List<Double> pesiTitoli) {
		this.pesiTitoli = pesiTitoli;
	}
	
	public Portfolio(List<String> titoliAzionari, List<Double> pesiTitoli) {
		super();
		this.titoliAzionari = titoliAzionari;
		this.pesiTitoli = pesiTitoli;
	}
	@Override
	public String toString() {
		return "Portfolio [titoliAzionari=" + titoliAzionari + ", pesiTitoli=" + pesiTitoli + "]";
	}
    
    
	
	
}
