package it.andrianid.ptfanalyzer.service.dto;

import java.util.List;

public class PortfolioDto {

	private List<String> titoliAzionari;
	private List<Double> pesoTitolo;

	public List<String> getTitoliAzionari() {
		return titoliAzionari;
	}
	
	public void setTitoliAzionari(List<String> titoliAzionari) {
		this.titoliAzionari = titoliAzionari;
	}

	public List<Double> getPesoTitolo() {
		return pesoTitolo;
	}

	public void setPesoTitolo(List<Double> pesoTitolo) {
		this.pesoTitolo = pesoTitolo;
	}

	public PortfolioDto() {
	}

	
	
	public PortfolioDto(List<String> titoliAzionari, List<Double> pesoTitolo) {
		super();
		this.titoliAzionari = titoliAzionari;
		this.pesoTitolo = pesoTitolo;
	}

	@Override
	public String toString() {
		return "PortfolioDto [titoliAzionari=" + titoliAzionari + ", pesoTitolo=" + pesoTitolo + "]";
	}
}

