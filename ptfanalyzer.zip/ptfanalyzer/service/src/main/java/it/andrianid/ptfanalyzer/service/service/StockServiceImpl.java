package it.andrianid.ptfanalyzer.service.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.andrianid.ptfanalyzer.service.dao.StockDao;
import it.andrianid.ptfanalyzer.service.dto.PortfolioDtoS;
import it.andrianid.ptfanalyzer.service.dto.StockDto;
import it.andrianid.ptfanalyzer.service.dto.StockDtoR;
import it.andrianid.ptfanalyzer.service.dto.StockDtoS;
import it.andrianid.ptfanalyzer.service.model.Stock;

public class StockServiceImpl implements StockServiceInterface {

	private Logger logger = LoggerFactory.getLogger(StockDao.class);

	public StockServiceImpl() {
		logger.debug("costruttore " + this.getClass().getName());
	}

	public List<StockDto> extractHistoricalData(String codTitolo) {
		StockDao stockDao = new StockDao();
		List<Stock> historicalData = stockDao.extractAllData(codTitolo);

		List<StockDto> stockDtoList = new ArrayList<>();

		for (Stock stock : historicalData) {
			StockDto stockDto = new StockDto(null, 0);
			stockDto.setDate(stock.getDate());
			stockDto.setClose(stock.getClose());
			stockDtoList.add(stockDto);
			logger.info("Dati estratti: " + stockDto.toString());
		}

		return stockDtoList;
	}

	public List<StockDtoR> extractRendimento(String codTitolo) {
		StockDao stockDao = new StockDao();
		List<Stock> rendimento = stockDao.extractAllData(codTitolo);

		List<StockDtoR> stockDtoRendimento = new ArrayList<>();

		for (Stock stock : rendimento) {
			StockDtoR stockDtoR = new StockDtoR(null, 0, 0, 0);
			stockDtoR.setDate(stock.getDate());
			stockDtoR.setClose(stock.getClose());
			stockDtoR.setRend(stock.getRend());
			stockDtoR.setRendPerc(stock.getRendPerc());

			stockDtoRendimento.add(stockDtoR);
			logger.info("Rendimenti estratti: " + stockDtoR.toString());
		}

		return stockDtoRendimento;

	}

	public List<StockDtoS> extractStat(String codTitolo) {
		StockDao stockDao = new StockDao();
		List<Stock> rend = stockDao.extractAllData(codTitolo);

		List<Double> rendimenti = new ArrayList<>();
		for (Stock stock : rend) {
			rendimenti.add(stock.getRend());
		}

		StockDtoS statistics = new StockDtoS(rendimenti);

		List<StockDtoS> stockDtoStatistics = new ArrayList<>();
		stockDtoStatistics.add(statistics);

		return stockDtoStatistics;
	}

	@Override
	public double extractPesoAVG(List<String> titoliAzionari, List<Double> pesiTitoli) {
		
		if (titoliAzionari == null || titoliAzionari.isEmpty()) {
            throw new IllegalArgumentException("Errore: titoliAzionari assenti o vuoti");
        }
		
		if (pesiTitoli == null || pesiTitoli.isEmpty()) {
            throw new IllegalArgumentException("Errore: pesiTitoli assenti o vuoti");
        }
		
		double sumPesi = pesiTitoli.stream().mapToDouble(Double::doubleValue).sum();
	    if (sumPesi > 1.0) {
	        throw new IllegalArgumentException("Errore: La somma dei pesi deve essere al massimo 1");
	    }
		
	    Map<String, Double> mediaRendimentiPerTitolo = new HashMap<>();

	    // Calcolo delle medie dei rendimenti per ciascun titolo azionario
	    for (int i = 0; i < titoliAzionari.size(); i++) {
	        List<StockDtoR> rendimentiTitolo = extractRendimento(titoliAzionari.get(i));
	        
	        if (rendimentiTitolo != null && !rendimentiTitolo.isEmpty()) {
	            double sum = 0.0;

	            // Calcola la somma dei rendimenti
	            for (StockDtoR rendimento : rendimentiTitolo) {
	                sum += rendimento.getRend();
	            }

	            // Calcola la media dei rendimenti
	            double media = sum / rendimentiTitolo.size();
	            mediaRendimentiPerTitolo.put(titoliAzionari.get(i), media);
	        }
	    }

	    double weightedReturnSum = 0.0;
	    double weightSum = 0.0;

	    // Utilizza le medie dei rendimenti e i pesi per calcolare la media ponderata
	    for (int i = 0; i < titoliAzionari.size(); i++) {
	        if (mediaRendimentiPerTitolo.containsKey(titoliAzionari.get(i))) {
	            double mediaRendimentoTitolo = mediaRendimentiPerTitolo.get(titoliAzionari.get(i));
	            double pesoTitolo = pesiTitoli.get(i);

	            weightedReturnSum += mediaRendimentoTitolo * pesoTitolo;
	            weightSum += pesoTitolo;
	        }
	    }

	    if (weightSum == 0.0) {
	        return 0; // Evita la divisione per zero
	    }

	    return weightedReturnSum / weightSum;
	}

	public List<PortfolioDtoS> extractStatPtf(List<String> titoliAzionari) {
	    if (titoliAzionari == null || titoliAzionari.isEmpty()) {
	        return new ArrayList<>(); // Restituisce una lista vuota se l'input è nullo o vuoto
	    }

	    List<PortfolioDtoS> statisticsList = new ArrayList<>();

	    for (String titolo : titoliAzionari) {
	        StockDao stockDao = new StockDao();
	        List<Stock> rendimenti = stockDao.extractAllData(titolo);

	        if (!rendimenti.isEmpty()) {
	            List<Double> rendimentiSingoloTitolo = new ArrayList<>();
	            for (Stock stock : rendimenti) {
	                rendimentiSingoloTitolo.add(stock.getRend());
	            }

	            StockDtoS statisticheTitolo = new StockDtoS(rendimentiSingoloTitolo);

	            PortfolioDtoS portfolioStat = new PortfolioDtoS(rendimentiSingoloTitolo, Collections.singletonList(titolo));
	            portfolioStat.setMediaRendimenti(statisticheTitolo.getMediaRendimenti());
	            portfolioStat.setDeviazioneStandard(statisticheTitolo.getDeviazioneStandard());
	            portfolioStat.setMassimoDrawdown(statisticheTitolo.getMassimoDrawdown());
	            portfolioStat.setMassimoRendimento(statisticheTitolo.getMassimoRendimento());
	            portfolioStat.setMinimoRendimento(statisticheTitolo.getMinimoRendimento());
	            portfolioStat.setValorePercentile99(statisticheTitolo.getValorePercentile99());

	            statisticsList.add(portfolioStat);
	        }
	    }

	    return statisticsList;
	}


}
