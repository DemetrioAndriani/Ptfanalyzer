package it.andrianid.ptfanalyzer.service.service;

import java.util.List;

import it.andrianid.ptfanalyzer.service.dto.PortfolioDtoS;
import it.andrianid.ptfanalyzer.service.dto.StockDto;
import it.andrianid.ptfanalyzer.service.dto.StockDtoR;
import it.andrianid.ptfanalyzer.service.dto.StockDtoS;


public interface StockServiceInterface {

	List<StockDto> extractHistoricalData(String codTitolo);
	
	List<StockDtoR> extractRendimento(String codTitolo);

	List<StockDtoS> extractStat(String codTitolo);
	
	List<PortfolioDtoS> extractStatPtf(List<String> titoliAzionari);
	
    double extractPesoAVG(List<String> titoliAzionari, List<Double> pesiTitoli);
    
    

}
