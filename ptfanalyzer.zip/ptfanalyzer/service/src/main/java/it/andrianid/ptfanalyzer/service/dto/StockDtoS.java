	package it.andrianid.ptfanalyzer.service.dto;
	
	import java.text.DecimalFormat;
	import java.util.List;
	
	public class StockDtoS {
	
	    protected double mediaRendimenti;
	    protected double deviazioneStandard;
	    protected double massimoRendimento;
	    protected double minimoRendimento;
	    protected double valorePercentile99;
	    protected double massimoDrawdown;

	   
	
	    public StockDtoS(List<Double> rendimenti) {
	        this.mediaRendimenti = calcolaMedia(rendimenti);
	        this.deviazioneStandard = calcolaDeviazioneStandard(rendimenti, mediaRendimenti);
	        this.massimoRendimento = calcolaMassimo(rendimenti);
	        this.minimoRendimento = calcolaMinimo(rendimenti);
	        this.valorePercentile99 = calcolaPercentile(rendimenti, 99);
	        this.massimoDrawdown = calcolaMassimoDrawdown(rendimenti);

	    }
	
	    
	    public double getMediaRendimenti() {
			return mediaRendimenti;
		}
	
	
	
		public void setMediaRendimenti(double mediaRendimenti) {
			this.mediaRendimenti = mediaRendimenti;
		}
	
	
	
		public double getDeviazioneStandard() {
			return deviazioneStandard;
		}
	
	
	
		public void setDeviazioneStandard(double deviazioneStandard) {
			this.deviazioneStandard = deviazioneStandard;
		}
	
	
	
		public double getMassimoRendimento() {
			return massimoRendimento;
		}
	
	
	
		public void setMassimoRendimento(double massimoRendimento) {
			this.massimoRendimento = massimoRendimento;
		}
	
	
	
		public double getMinimoRendimento() {
			return minimoRendimento;
		}
	
	
	
		public void setMinimoRendimento(double minimoRendimento) {
			this.minimoRendimento = minimoRendimento;
		}
	
	
	
		public double getValorePercentile99() {
			return valorePercentile99;
		}
	
	
	
		public void setValorePercentile99(double valorePercentile99) {
			this.valorePercentile99 = valorePercentile99;
		}
	
	
		public double getMassimoDrawdown() {
			return massimoDrawdown;
		}


		public void setMassimoDrawdown(double massimoDrawdown) {
			this.massimoDrawdown = massimoDrawdown;
		}


		 @Override
		    public String toString() {
		        DecimalFormat df = new DecimalFormat("#.######");

		        String formattedMedia = df.format(mediaRendimenti);
		        String formattedDeviazione = df.format(deviazioneStandard);
		        String formattedMassimo = df.format(massimoRendimento);
		        String formattedMinimo = df.format(minimoRendimento);
		        String formattedPercentile = df.format(valorePercentile99);
		        String formattedDrawdown = df.format(massimoDrawdown);

		        return "[mediaRendimenti=" + formattedMedia + ", deviazioneStandard=" + formattedDeviazione + ", massimoRendimento=" + formattedMassimo
		                + ", minimoRendimento=" + formattedMinimo + ", valorePercentile99=" + formattedPercentile
		                + ", massimoDrawdown=" + formattedDrawdown+ "]";
		    }
	
		// Metodi per calcolare la media, la deviazione standard, il massimo, il minimo e il valore al percentile 99
	    protected double calcolaMedia(List<Double> data) {
	        double sum = 0.0;
	        for (double value : data) {
	            sum += value;
	        }
	        return sum / data.size();
	    }
	
	    protected double calcolaDeviazioneStandard(List<Double> data, double media) {
	        double sumOfSquaredDifferences = 0.0;
	        for (double value : data) {
	            double diff = value - media;
	            sumOfSquaredDifferences += diff * diff;
	        }
	        return Math.sqrt(sumOfSquaredDifferences / data.size());
	    }
	
	    protected double calcolaMassimo(List<Double> data) {
	        return data.stream().mapToDouble(Double::doubleValue).max().orElse(0);
	    }
	
	    protected double calcolaMinimo(List<Double> data) {
	        return data.stream().mapToDouble(Double::doubleValue).min().orElse(0);
	    }
	
	    protected double calcolaPercentile(List<Double> data, int percentile) {
	        int index = (int) Math.ceil((percentile / 100.0) * data.size()) - 1;
	        return data.stream().sorted().skip(index).findFirst().orElse((double) 0);
	    }
	    
	    protected double calcolaMassimoDrawdown(List<Double> data) {
	        double maxDrawdown = 0.0;
	        double currentDrawdown = 0.0;

	        for (int i = 0; i < data.size(); i++) {
	            double value = data.get(i);
	            if (value < 0) {
	                currentDrawdown += value;
	                if (currentDrawdown < maxDrawdown) {
	                    maxDrawdown = currentDrawdown;
	                }
	            } else {
	                currentDrawdown = 0;
	            }
	        }
	        return maxDrawdown;
	    }
	}
	
