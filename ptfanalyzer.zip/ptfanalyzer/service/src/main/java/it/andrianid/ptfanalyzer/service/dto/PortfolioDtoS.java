package it.andrianid.ptfanalyzer.service.dto;

import java.text.DecimalFormat;
import java.util.List;

public class PortfolioDtoS extends StockDtoS {

	private List<String> titoliAzionari;

	public PortfolioDtoS(List<Double> rendimenti, List<String> titoliAzionari) {
		super(rendimenti);
		this.titoliAzionari = titoliAzionari;
		this.mediaRendimenti = calcolaMedia(rendimenti);
        this.deviazioneStandard = calcolaDeviazioneStandard(rendimenti, mediaRendimenti);
        this.massimoRendimento = calcolaMassimo(rendimenti);
        this.minimoRendimento = calcolaMinimo(rendimenti);
        this.valorePercentile99 = calcolaPercentile(rendimenti, 99);
        this.massimoDrawdown = calcolaMassimoDrawdown(rendimenti);
	}

	public List<String> getTitoliAzionari() {
		return titoliAzionari;
	}

	public void setTitoliAzionari(List<String> titoliAzionari) {
		this.titoliAzionari = titoliAzionari;
	}

	@Override
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.######");

        String formattedMedia = df.format(mediaRendimenti);
        String formattedDeviazione = df.format(deviazioneStandard);
        String formattedMassimo = df.format(massimoRendimento);
        String formattedMinimo = df.format(minimoRendimento);
        String formattedPercentile = df.format(valorePercentile99);
        String formattedDrawdown = df.format(massimoDrawdown);
        
		return "[titoliAzionari=" + titoliAzionari + ", mediaRendimenti=" + formattedMedia + ", deviazioneStandard=" + formattedDeviazione + ", massimoRendimento=" + formattedMassimo
                + ", minimoRendimento=" + formattedMinimo + ", valorePercentile99=" + formattedPercentile
                + ", massimoDrawdown=" + formattedDrawdown+ "]";
	}
	
	
	
}
