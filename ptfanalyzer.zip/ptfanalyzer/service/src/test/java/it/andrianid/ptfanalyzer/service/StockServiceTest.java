package it.andrianid.ptfanalyzer.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import it.andrianid.ptfanalyzer.service.dto.*;
import it.andrianid.ptfanalyzer.service.service.StockServiceImpl;
import it.andrianid.ptfanalyzer.service.service.StockServiceInterface;

public class StockServiceTest {
	private int historicalDataRecord = 938;

	@Test
	public void testReadAll() {

		StockServiceInterface service = new StockServiceImpl();
		List<StockDto> res=  service.extractHistoricalData("AMZN");// INSERIRE NOME STOCK DESIDERATO

		assertNotNull(service);
		assertEquals(historicalDataRecord, res.size());


	}
}