package it.andrianid.ptfanalyzer.webapp;

import java.text.DecimalFormat;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import it.andrianid.ptfanalyzer.service.dto.PortfolioDto;
import it.andrianid.ptfanalyzer.service.dto.PortfolioDtoS;
import it.andrianid.ptfanalyzer.service.dto.StockDto;
import it.andrianid.ptfanalyzer.service.dto.StockDtoR;
import it.andrianid.ptfanalyzer.service.dto.StockDtoS;
import it.andrianid.ptfanalyzer.service.service.StockServiceImpl;
import it.andrianid.ptfanalyzer.service.service.StockServiceInterface;

@Path("/ptfanalyzer")
public class PtfanalyzerService {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getTestService() {
		return "Hello Worlddd! This is coming from webservice!!";
	}

	@POST
	@Path("/historical")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getHistoricalData(String codTitolo) {
		StockServiceInterface service = new StockServiceImpl();
		List<StockDto> res = service.extractHistoricalData(codTitolo);
		if (res != null && !res.isEmpty()) {
			return Response.status(Response.Status.OK).entity("I Dati storici del titolo sono:" + res).build();
		} else {
			return Response.status(Response.Status.OK).entity("Dati storici non disponibili").build();
		}
	}

	@POST
	@Path("/rendimentoTitolo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRendimento(String codTitolo) {
		StockServiceInterface service = new StockServiceImpl();
		List<StockDtoR> res = service.extractRendimento(codTitolo);
		if (res != null && !res.isEmpty()) {
			return Response.status(Response.Status.OK).entity("I Rendimenti del titolo sono:"+res).build();
		} else {
			return Response.status(Response.Status.OK).entity("Rendimenti non disponibili").build();
		}
	}

	@POST
	@Path("/statTitolo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatistics(String codTitolo) {
		StockServiceInterface service = new StockServiceImpl();
		List<StockDtoS> res = service.extractStat(codTitolo);
		if (res != null && !res.isEmpty()) {
			return Response.status(Response.Status.OK).entity("Le Statistiche titolo sono :" + res).build();
		} else {
			return Response.status(Response.Status.OK).entity("Statistiche non disponibili").build();
		}
	}
	
	
	
	@POST
	@Path("/statTitoliPtf")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPortfolioStatistics(PortfolioDto portfolio) {
	    StockServiceInterface service = new StockServiceImpl();
	    List<String> titoliAzionari = portfolio.getTitoliAzionari();

	    List<PortfolioDtoS> statistics = service.extractStatPtf(titoliAzionari);

	    if (statistics != null && !statistics.isEmpty()) {
	    	
	        return Response.status(Response.Status.OK).entity("Le Statistiche portfolio sono :" + statistics).build();
	    } else {
	        return Response.status(Response.Status.OK).entity("Statistiche portfolio non disponibili").build();
	    }
	}

	
	
	
	@POST
	@Path("/portfolioRendimentoMedioPesato") 
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPesoAVG(PortfolioDto portfolio) {
	    StockServiceInterface service = new StockServiceImpl();
	    List<String> titoliAzionari = portfolio.getTitoliAzionari();
	    List<Double> pesiTitoli = portfolio.getPesoTitolo();

	    double weightedAverageReturn = service.extractPesoAVG(titoliAzionari, pesiTitoli);

	    if (weightedAverageReturn >= 0) {
	    	DecimalFormat decimalFormat = new DecimalFormat("#.######"); 
	        String formattedweightedAverageReturn = decimalFormat.format(weightedAverageReturn);

	        return Response.status(Response.Status.OK).entity("Il rendimento medio pesato del portfolio è: " + formattedweightedAverageReturn).build();
	    } else {
	        return Response.status(Response.Status.BAD_REQUEST).entity("Errore nel calcolo del rendimento medio pesato").build();
	    }
	}


}
