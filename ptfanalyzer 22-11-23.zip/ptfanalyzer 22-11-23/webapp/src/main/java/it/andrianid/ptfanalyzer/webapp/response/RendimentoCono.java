package it.andrianid.ptfanalyzer.webapp.response;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RendimentoCono {
	private Date date;
	private double percentile5;
	private double percentile50;
	private double percentile95;
	
	public String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(date);
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	public double getPercentile5() {
		return percentile5;
	}
	public void setPercentile5(double percentile5) {
		this.percentile5 = percentile5;
	}
	public double getPercentile50() {
		return percentile50;
	}
	public void setPercentile50(double percentile50) {
		this.percentile50 = percentile50;
	}
	public double getPercentile95() {
		return percentile95;
	}
	public void setPercentile95(double percentile95) {
		this.percentile95 = percentile95;
	}
	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate = sdf.format(date);

		return "RendimentiConoDto [date=" + formattedDate + ", percentile5=" + percentile5 + ", percentile50=" + percentile50
				+ ", percentile95=" + percentile95 + "]";
	}
	public RendimentoCono() {
		super();
		this.date = date;
		this.percentile5 = percentile5;
		this.percentile50 = percentile50;
		this.percentile95 = percentile95;
	}



}
