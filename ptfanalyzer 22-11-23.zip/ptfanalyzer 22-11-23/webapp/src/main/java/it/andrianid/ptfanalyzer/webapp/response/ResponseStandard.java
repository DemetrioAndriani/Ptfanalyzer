package it.andrianid.ptfanalyzer.webapp.response;


public class ResponseStandard {

	private int status; 
	private String message;
	private String generatedAt;
    private String uniqueId; 
    private long elaborationInMilliSec;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getGeneratedAt() {
		return generatedAt;
	}

	public void setGeneratedAt(String generatedAt) {
		this.generatedAt = generatedAt;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public long getElaborationInMilliSec() {
		return elaborationInMilliSec;
	}

	public void setElaborationInMilliSec(long elaborationInMilliSec) {
		this.elaborationInMilliSec = elaborationInMilliSec;
	}

	

	

	

}
