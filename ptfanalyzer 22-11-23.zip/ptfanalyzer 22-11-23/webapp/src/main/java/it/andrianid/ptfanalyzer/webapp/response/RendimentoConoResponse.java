package it.andrianid.ptfanalyzer.webapp.response;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import it.andrianid.ptfanalyzer.service.dto.RendimentoConoDto;

public class RendimentoConoResponse extends ResponseStandard {

	private Date date;
	private List<RendimentoConoDto> rendimentoCono;

	// Costruttore
	public RendimentoConoResponse() {
		this.date = new Date();
	}

	public String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(date);
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<RendimentoConoDto> getRendimentoCono() {
		return rendimentoCono;
	}

	public void setRendimentoCono(List<RendimentoConoDto> risultati) {
		this.rendimentoCono = risultati;
	}
}
