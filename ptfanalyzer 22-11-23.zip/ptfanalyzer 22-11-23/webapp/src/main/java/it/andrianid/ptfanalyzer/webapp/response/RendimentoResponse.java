package it.andrianid.ptfanalyzer.webapp.response;

import java.util.List;

import it.andrianid.ptfanalyzer.service.dto.RendimentiDto;



public class RendimentoResponse extends ResponseStandard{
	private List<RendimentiDto> rendimentoData;

	public List<RendimentiDto> getRendimentoData() {
		return rendimentoData;
	}

	public void setRendimentoData(List<RendimentiDto> res) {
		this.rendimentoData = res;
	}

}
