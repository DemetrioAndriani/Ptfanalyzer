package it.andrianid.ptfanalyzer.service.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.andrianid.ptfanalyzer.service.dao.TitoloDao;
import it.andrianid.ptfanalyzer.service.dto.PtfStatisticheDto;
import it.andrianid.ptfanalyzer.service.dto.RendimentiDto;
import it.andrianid.ptfanalyzer.service.dto.StatisticheDto;
import it.andrianid.ptfanalyzer.service.model.OsservazioneStorica;
import it.andrianid.ptfanalyzer.service.model.Posizione;
import it.andrianid.ptfanalyzer.service.model.StatisticaAllaData;

public class StockServiceImpl implements StockServiceInterface {

	private Logger logger = LoggerFactory.getLogger(TitoloDao.class);

	public StockServiceImpl() {
		logger.debug("costruttore " + this.getClass().getName());
	}

	public List<StatisticaAllaData> bootstrap(String codTitolo) {
		TitoloDao stockDao = new TitoloDao();
		long seed = 1234;
		Random random = new Random(seed);
		List<OsservazioneStorica> titoli = stockDao.extractAllData(codTitolo);

		List<StatisticaAllaData> stockStatisticheAllaData = new ArrayList<>();

		int numeroScenariFuturi = 100;

		for (int i = 0; i < numeroScenariFuturi; i++) {
			StatisticaAllaData statisticaAllaData = new StatisticaAllaData(null, 0);

			// Pesca casualmente la data e il rendimento dalla lista
			int index = random.nextInt(titoli.size());
			OsservazioneStorica randomStock = titoli.get(index);

			statisticaAllaData.setData(randomStock.getDate());
			statisticaAllaData.setRendimento(randomStock.getRend());

			stockStatisticheAllaData.add(statisticaAllaData);
			logger.info("Statistica Alla Data estratti: " + statisticaAllaData.toString());
		}

		return stockStatisticheAllaData;
	}

	public double[] calcolaRendimentiCumulati(List<StatisticaAllaData> stockDtoStatistiche) {
		int n = stockDtoStatistiche.size();
		double[] rendimentiCumulati = new double[n];

		// Inizializza il primo valore dei rendimenti cumulati
		rendimentiCumulati[0] = stockDtoStatistiche.get(0).getRendimento();

		for (int t = 1; t < n; t++) {
			double rendimentoCorrente = stockDtoStatistiche.get(t).getRendimento();
			rendimentiCumulati[t] = (1 + rendimentiCumulati[t - 1]) * (1 + rendimentoCorrente) - 1;
		}

		return rendimentiCumulati;
	}

	public double[] calcolaPercentile(double[] rendimentiCumulati, int percentuale) {
		if (rendimentiCumulati == null || rendimentiCumulati.length == 0) {
			throw new IllegalArgumentException("L'array dei rendimenti cumulati è vuoto o nullo.");
		}

		// Ordina l'array dei rendimenti cumulati
		double[] sortedArray = Arrays.copyOf(rendimentiCumulati, rendimentiCumulati.length);
		Arrays.sort(sortedArray);

		// Calcola l'indice del percentile
		int index = (int) Math.ceil((percentuale / 100.0) * sortedArray.length) - 1;

		// Restituisci il valore corrispondente all'indice calcolato come array
		return new double[] { sortedArray[index] };
	}

	// somma per giornate successive
	public double[] sommaArray(double[] array1, double[] array2) {
		if (array1.length != array2.length) {
			throw new IllegalArgumentException("Gli array devono avere la stessa lunghezza");
		}

		double[] somma = new double[array1.length];
		for (int i = 0; i < array1.length; i++) {
			somma[i] = array1[i] + array2[i];
		}

		return somma;
	}
	
	
	
	
	
	
	
	
	
	
	
	//da qui fine metodo 4
	public List<RendimentiDto> extractRendimento(String titolo) {
		TitoloDao stockDao = new TitoloDao();
		List<OsservazioneStorica> titoli = stockDao.extractAllData(titolo);

		List<RendimentiDto> stockDtoRendimento = new ArrayList<>();

		for (OsservazioneStorica stock : titoli) {
			RendimentiDto stockDtoR = new RendimentiDto(null, 0, 0, 0);
			stockDtoR.setDate(stock.getDate());
			stockDtoR.setClose(stock.getClose());
			stockDtoR.setRend(stock.getRend());
			stockDtoR.setRendPerc(stock.getRendPerc());

			stockDtoRendimento.add(stockDtoR);
			logger.info("Rendimenti estratti: " + stockDtoR.toString());
		}

		return stockDtoRendimento;

	}

	public List<StatisticheDto> extractStat(String codTitolo) {
		TitoloDao stockDao = new TitoloDao();
		List<OsservazioneStorica> rend = stockDao.extractAllData(codTitolo);

		List<Double> rendimenti = new ArrayList<>();
		for (OsservazioneStorica stock : rend) {
			rendimenti.add(stock.getRend());
		}

		StatisticheDto statistics = new StatisticheDto(rendimenti);

		List<StatisticheDto> stockDtoStatistics = new ArrayList<>();
		stockDtoStatistics.add(statistics);

		return stockDtoStatistics;
	}

	public Map<String, Double> extractPesiDaControvalori(List<Posizione> titoliAzionari) {
		if (titoliAzionari == null || titoliAzionari.isEmpty()) {
			throw new IllegalArgumentException("Errore: titoliAzionari assenti o vuoti");
		}

		Map<String, Double> pesiTitoli = new HashMap<>();
		double sum = 0.0;

		// Calcolo della somma totale dei controvalori
		for (Posizione posizione : titoliAzionari) {
			sum += posizione.getControvalore();
		}

		// Calcolo dei pesi in base ai controvalori
		for (Posizione posizione : titoliAzionari) {
			String titolo = posizione.getCodTitolo();
			double controvalore = posizione.getControvalore();

			double peso = controvalore / sum;
			if (peso > 1.0 || peso <= 0.0) {
				throw new IllegalArgumentException("Errore: La somma dei pesi deve essere compresa tra 0 e 1");
			}
			pesiTitoli.put(titolo, peso);
		}

		return pesiTitoli;
	}

	@Override
	public double calcolaRendimentoMedioPesato(List<Posizione> titoliAzionari) {
		if (titoliAzionari == null || titoliAzionari.isEmpty()) {
			throw new IllegalArgumentException("Errore: titoliAzionari assenti o vuoti");
		}

		Map<String, Double> pesiTitoli = extractPesiDaControvalori(titoliAzionari);

		double weightedReturnSum = 0.0;
		double weightSum = 0.0;

		// Itera attraverso le posizioni anziché la mappa
		for (Posizione posizione : titoliAzionari) {
			String titolo = posizione.getCodTitolo();
			double controvalore = posizione.getControvalore();

			if (pesiTitoli.containsKey(titolo)) {
				double pesoTitolo = pesiTitoli.get(titolo);
				List<RendimentiDto> rendimentiTitolo = extractRendimento(titolo);

				if (rendimentiTitolo != null && !rendimentiTitolo.isEmpty()) {
					double sum = 0.0;

					// Calcola la somma dei rendimenti
					for (RendimentiDto rendimento : rendimentiTitolo) {
						sum += rendimento.getRend();
					}

					// Calcola la media dei rendimenti per il titolo
					double mediaRendimentoTitolo = sum / rendimentiTitolo.size();

					weightedReturnSum += mediaRendimentoTitolo * (pesoTitolo * controvalore);
					weightSum += pesoTitolo * controvalore;
				}
			}
		}

		if (weightSum == 0.0) {
			return 0; // Evita la divisione per zero
		}

		return weightedReturnSum / weightSum;
	}

	@Override
	public List<PtfStatisticheDto> extractStatPtf(List<Posizione> titoliAzionari) {
		if (titoliAzionari == null || titoliAzionari.isEmpty()) {
			return new ArrayList<>();
		}

		List<PtfStatisticheDto> statisticsList = new ArrayList<>();

		for (Posizione posizione : titoliAzionari) {
			String titolo = posizione.getCodTitolo();
			// Double controvalore = posizione.getControvalore();

			TitoloDao stockDao = new TitoloDao();
			List<OsservazioneStorica> rendimenti = stockDao.extractAllData(titolo);

			if (!rendimenti.isEmpty()) {
				List<Double> rendimentiSingoloTitolo = new ArrayList<>();
				for (OsservazioneStorica stock : rendimenti) {
					rendimentiSingoloTitolo.add(stock.getRend());
				}

				StatisticheDto statisticheTitolo = new StatisticheDto(rendimentiSingoloTitolo);

				PtfStatisticheDto portfolioStat = new PtfStatisticheDto(rendimentiSingoloTitolo,
						Collections.singletonList(titolo));
				portfolioStat.setMediaRendimenti(statisticheTitolo.getMediaRendimenti());
				portfolioStat.setDeviazioneStandard(statisticheTitolo.getDeviazioneStandard());
				portfolioStat.setMassimoDrawdown(statisticheTitolo.getMassimoDrawdown());
				portfolioStat.setMassimoRendimento(statisticheTitolo.getMassimoRendimento());
				portfolioStat.setMinimoRendimento(statisticheTitolo.getMinimoRendimento());
				portfolioStat.setValorePercentile99(statisticheTitolo.getValorePercentile99());

				statisticsList.add(portfolioStat);
			}
		}

		return statisticsList;
	}

}
